#pragma once
#ifndef INDUSTRIAL_H
#define INDUSTRIAL_H
#include "loc.h"
#include "residential.h"
using namespace std;

void updateIndustrial(vector<vector<loc> > &region, int& workers, int& goods);

#endif
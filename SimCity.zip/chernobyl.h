#pragma once
#ifndef CHERNOBYL_H
#define CHERNOBYL_H
#include "industrial.h"
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <string>
void game(vector<vector<loc> >& region, int& sick);
void printt(vector<vector<loc> >& region);
#endif

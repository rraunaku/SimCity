#pragma once
#ifndef COMMERCIAL_H
#define COMMERCIAL_H
#include "loc.h"
#include "residential.h"
using namespace std;

void updateCommercial(vector<vector<loc> >& region, int& workers, int& goods);
#endif